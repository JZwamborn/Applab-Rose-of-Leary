__author__ = 'Daphne Lenders'
import re
import xlrd
import numpy as np
import nltk
from textblob import TextBlob
from collections import defaultdict
from heapq import nlargest
from sklearn import model_selection

possibleTags = ['CC', 'CD', 'DT', 'EX', 'FW', 'IN', 'JJ', 'JJR', 'JJS', 'MD', 'NN', 'NNS', 'NNP', 'NNPS', 'PDT', 'POS', 'RB',
                'RBR', 'RBS', 'RP', 'TO', 'UH', 'VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ', 'WDT', 'WP', 'WP$', 'WRB']

stop_words_all = ['must', 'musnt', 'can', 'cant', 'could', 'couldnt', 'need', 'needs', 'should', 'shouldnt', 'is', 'isnt', 'are', 'arent', 'would',
              'wouldnt', 'aint', 'had', 'has', 'hasnt', 'have', 'hadnt', 'havent', 'having', 'it', 'its', 'itself',
               'than', 'where', 'does', 'doesnt', 'dont', 'do', 'didnt', 'did', 'were', 'werent', 'before',
              'doing', 'a', 'an', 'so', 'own', 'above', 'and', 'such', 'then', 'from',
              'for', 'any', 'how', 'again', 'very', 'but', 'once', 'because',
              'some', 'wont', 'to', 'these', 'with', 'the', 'them', 'both', 'few', 'after', 'wasnt',
              'be', 'been', 'against', 'on', 'off', 'too', 'under', 'why', 'who', 'our', 'in', 'if', 'other',
              'until', 'down', 'during', 'was', 'over', 'those', 'further', 'same', 'that', 'thats', 'of', 'up',
              'what', 'just', 'will', 'as', 'no', 'each', 'being', 'now', 'all', 'by', 'into', 'when', 'most',
              'not', 'theirs', 'they', 'at', 'out', 'below', 'whom', 'nor', 'here', 'through', 'more', 'or',
              'only', 'about', 'which', 'there', 'theres', 'this', 'between', 'while', 'might', 'she', 'shes', 'shell', 'her', 'herself',
              'he', 'hes', 'hell', 'him', 'his', 'himself', 'i', 'me', 'myself', 'my', 'im', 'id', 'ill', 'am', 'you', 'youre', 'youll', 'your', 'yours',
              'yourself', 'youve', 'youd', 'we']


file_location = 'data/SongData.xlsx'
workbook = xlrd.open_workbook(file_location)
sheet = workbook.sheet_by_index(0)

sheet_array = []

# The song data is extracted from the excel sheet
for row in range(1, sheet.nrows):
    sheet_row = []
    for col in range(1, sheet.ncols - 1):
        sheet_row.append(sheet.cell_value(row, col))
    sheet_array.append(sheet_row)

data = np.asmatrix(sheet_array)



# This function checks whether the lyrics of the song are not labelled with 'N A' or 'instrumental' by checking whether the
# number of words in the lyrics is larger than 2
def checkForValidity(song):
    words = re.compile('\w+').findall(song)
    return len(words) > 2

lyrics60s = np.array([])
lyrics70s = np.array([])
lyrics80s = np.array([])
lyrics90s = np.array([])
lyrics00s = np.array([])
lyrics10s = np.array([])
lyricLabels = np.array([])
#the lyrics are added to their-corresponding lyric-array, and the production-decades are stored in a vector as well
for row in range(data.shape[0]):
    year = float(data[row,2])
    song = data[row, 3]
    validLyrics = checkForValidity(song)
    if validLyrics:
        if year < 1970.0:
            lyrics60s = np.append(lyrics60s, song)
            lyricLabels = np.append(lyricLabels, '1960')
        elif year < 1980.0:
            lyrics70s = np.append(lyrics70s, song)
            lyricLabels = np.append(lyricLabels, '1970')
        elif year < 1990.0:
            lyrics80s = np.append(lyrics80s, song)
            lyricLabels = np.append(lyricLabels, '1980')
        elif year < 2000.0:
            lyrics90s = np.append(lyrics90s, song)
            lyricLabels = np.append(lyricLabels, '1990')
        elif year < 2010.0:
            lyrics00s = np.append(lyrics00s, song)
            lyricLabels = np.append(lyricLabels, '2000')
        elif year < 2020.0:
            lyrics10s = np.append(lyrics10s, song)
            lyricLabels = np.append(lyricLabels, '2010')

# All the lyrics are stored in one lyric vector
lyricsAll = np.hstack((lyrics60s, lyrics70s, lyrics80s, lyrics90s, lyrics00s, lyrics10s))
# The data is splitted into a training and test set (where the train set consists of 75% of all data)
lyrics_train, lyrics_test, lyricsLabels_train, lyricsLabels_test = model_selection.train_test_split(lyricsAll, lyricLabels, test_size=0.25, random_state=1)

#The 60s lyrics of the training-set are stored into one vector, such that later on the most commonly used 60s n-grams can be
#calculated
indeces60s=np.where(lyricsLabels_train == '1960')
lyrics_train60 = lyrics_train[indeces60s]

#The 70s lyrics of the training-set are stored into one vector, such that later on the most commonly used 70s n-grams can be
#calculated
indeces70s=np.where(lyricsLabels_train == '1970')
lyrics_train70 = lyrics_train[indeces70s]

#The 80s lyrics of the training-set are stored into one vector, such that later on the most commonly used 80s n-grams can be
#calculated
indeces80s=np.where(lyricsLabels_train == '1980')
lyrics_train80 = lyrics_train[indeces80s]

#The 90s lyrics of the training-set are stored into one vector, such that later on the most commonly used 90s n-grams can be
#calculated
indeces90s=np.where(lyricsLabels_train == '1990')
lyrics_train90 = lyrics_train[indeces90s]

#The 00s lyrics of the training-set are stored into one vector, such that later on the most commonly used 00s n-grams can be
#calculated
indeces00s=np.where(lyricsLabels_train == '2000')
lyrics_train00 = lyrics_train[indeces00s]

#The 10s lyrics of the training-set are stored into one vector, such that later on the most commonly used 10s n-grams can be
#calculated
indeces10s=np.where(lyricsLabels_train == '2010')
lyrics_train10 = lyrics_train[indeces10s]


# This function gets as input all lyrics from a dataset. For all words in the lyrics the function will compute
# in how many other songtexts that word can be found
def calcDocumentFrequencyVector(allLyrics):
    wordsAlreadyChecked = []
    DF = defaultdict(int)
    for lyrics in allLyrics:
        lyrics = lyrics.lower()
        words = re.compile('\w+').findall(lyrics)
        for word in words:
            if word not in wordsAlreadyChecked and word not in stop_words_all:
                DF[word] +=1
                wordsAlreadyChecked.append(word)
        wordsAlreadyChecked = []
    return DF

# This function calculated how often a queriedRepeition occurs in a song. If e.g. queriedRepetition is equal to 1
# the function calculates how many unique words are in a song. If the queriedRepetition is equal to 2 it calculated
# how many words occur twice in a song (and so on)
def calcNumberOfRepetitions(tokens, song, queriedRepetition):
    numberOfQueriedRepetitions = 0
    tokensAlreadyChecked = []
    for token in tokens:
        if token not in tokensAlreadyChecked:
            numberOfOccurences = sum(1 for _ in re.finditer(r'\b%s\b' % re.escape(token), song))
            if (numberOfOccurences == queriedRepetition):
                numberOfQueriedRepetitions += 1
            tokensAlreadyChecked.append(token)
    return numberOfQueriedRepetitions

#This function calculates what the average word length of all the words in a song is
def calcAverageWordLength(tokens, numberOfWords):
    lengthSum = 0
    for token in tokens:
        lengthSum += len(token)
    return lengthSum/numberOfWords

#This function calculates how often a queried POS-tag occurs in a song, given all the POS-tags for the words in the song.
def calcTagOccurences(partOfSpeechTags, queriedTag):
    tagOccurences = 0
    for tag in partOfSpeechTags:
        if tag[1] == queriedTag:
            tagOccurences+=1
    return tagOccurences

#This function generates the bigrams of one song
def generate_bigrams_one_song(words):
    length = len(words)
    bigrams = []
    for i in range(length-1):
        if not (words[i] in stop_words_all and words[i + 1] in stop_words_all):
            bigrams.append((words[i], words[i + 1]))
    return bigrams

#This function generates the bigrams of multiple songs
def generate_bigrams(allLyrics):
    bigramsPerSong = []
    for lyrics in allLyrics:
        bigrams = []
        words = re.compile('\w+').findall(lyrics)
        length = len(words)
        for i in range(length-1):
            if not (words[i] in stop_words_all and words[i+1] in stop_words_all):
                bigram = (words[i], words[i+1])
                bigrams.append(bigram)
        bigramsPerSong.append(bigrams)
    return bigramsPerSong

#This function generates trigrams for one song
def generate_trigrams_one_song(words):
    length = len(words)
    trigrams = []
    for i in range(length - 2):
        if not (words[i] in stop_words_all and words[i + 1] in stop_words_all and words [i+2] in stop_words_all):
            trigrams.append((words[i], words[i + 1], words[i+2]))
    return trigrams

#This function generates trigrams for multiple songs
def generate_trigrams(allLyrics):
    trigramsPerSong = []
    for lyrics in allLyrics:
        trigrams = []
        words = re.compile('\w+').findall(lyrics)
        length = len(words)
        for i in range(length - 2):
            if not (words[i] in stop_words_all and words[i + 1] in stop_words_all and words [i+2] in stop_words_all):
                trigram = (words[i], words[i + 1], words[i+2])
                trigrams.append(trigram)
        trigramsPerSong.append(trigrams)
    return trigramsPerSong

#Given a vector of ngrams, this function stores the frequency of each n-gram in this vector in a dictionary
def calc_ngram_frequencies(ngrams):
    ngramsAlreadyChecked = []
    ngramFrequencies = defaultdict(int)
    for song in ngrams:
        for ngram in song:
            if ngram not in ngramsAlreadyChecked:
                ngramFrequencies[ngram] += 1
                ngramsAlreadyChecked.append(ngram)
        ngramsAlreadyChecked = []
    return ngramFrequencies

# Given all n-grams in a song, and some queried n-gram this function calculates how often the queried n-gram occurs
# in the code
def calc_ngram_occurence(ngrams, queriedNgram):
    numberOfngramOccurences = 0
    for ngram in ngrams:
        if ngram==queriedNgram:
            numberOfngramOccurences += 1
    return numberOfngramOccurences



# In this function the 250 most frequently used words of the different decades, are merged into one list
def generateCommonWords():
    dfs60Words = calcDocumentFrequencyVector(lyrics_train60)
    dfs70Words = calcDocumentFrequencyVector(lyrics_train70)
    dfs80Words = calcDocumentFrequencyVector(lyrics_train80)
    dfs90Words = calcDocumentFrequencyVector(lyrics_train90)
    dfs00Words = calcDocumentFrequencyVector(lyrics_train00)
    dfs10Words = calcDocumentFrequencyVector(lyrics_train10)

    common60Words = nlargest(250, dfs60Words, key=dfs60Words.get)
    common70Words = nlargest(250, dfs70Words, key=dfs70Words.get)
    common80Words = nlargest(250, dfs80Words, key=dfs80Words.get)
    common90Words = nlargest(250, dfs90Words, key=dfs90Words.get)
    common00Words = nlargest(250, dfs00Words, key=dfs00Words.get)
    common10Words = nlargest(250, dfs10Words, key=dfs10Words.get)

    commonWords = common60Words + common70Words + common80Words + common90Words + common00Words + common10Words
    commonWordsWithoutDuplicates = list(set(commonWords))

    return commonWordsWithoutDuplicates

#This function can be e.g. called in the following manner: calcSpecialWords(common60Words, (common70Words + common80Words + common90Words + common00Words + common10Words))
#By calling it in this way the function would calculate the words that have made the list of most frequently used words of the 60s but not of the other decades
def calcSpecialWords(listOfInterest, rest):
    specialWords = [x for x in listOfInterest if x not in rest]
    print(specialWords)

# In this function the 250 most frequently used bigrams of the different decades, are merged into one list
def generateCommonBigrams():
    bigram60s_frequencies = calc_ngram_frequencies(generate_bigrams(lyrics_train60))
    bigram70s_frequencies = calc_ngram_frequencies(generate_bigrams(lyrics_train70))
    bigram80s_frequencies = calc_ngram_frequencies(generate_bigrams(lyrics_train80))
    bigram90s_frequencies = calc_ngram_frequencies(generate_bigrams(lyrics_train90))
    bigram00s_frequencies = calc_ngram_frequencies(generate_bigrams(lyrics_train00))
    bigram10s_frequencies = calc_ngram_frequencies(generate_bigrams(lyrics_train10))

    commonBigrams60s = nlargest(250, bigram60s_frequencies, key=bigram60s_frequencies.get)
    commonBigrams70s = nlargest(250, bigram70s_frequencies, key=bigram70s_frequencies.get)
    commonBigrams80s = nlargest(250, bigram80s_frequencies, key=bigram80s_frequencies.get)
    commonBigrams90s = nlargest(250, bigram90s_frequencies, key=bigram90s_frequencies.get)
    commonBigrams00s = nlargest(250, bigram00s_frequencies, key=bigram00s_frequencies.get)
    commonBigrams10s = nlargest(250, bigram10s_frequencies, key=bigram10s_frequencies.get)

    commonBigrams = commonBigrams60s + commonBigrams70s + commonBigrams80s + commonBigrams90s + commonBigrams00s + commonBigrams10s
    commonBigramsWithoutDuplicates = list(set(commonBigrams))

    return commonBigramsWithoutDuplicates

# In this function the 250 most frequently used trigrams of the different decades, are merged into one list
def generateCommonTrigrams():
    trigram60s_frequencies = calc_ngram_frequencies(generate_trigrams(lyrics_train60))
    trigram70s_frequencies = calc_ngram_frequencies(generate_trigrams(lyrics_train70))
    trigram80s_frequencies = calc_ngram_frequencies(generate_trigrams(lyrics_train80))
    trigram90s_frequencies = calc_ngram_frequencies(generate_trigrams(lyrics_train90))
    trigram00s_frequencies = calc_ngram_frequencies(generate_trigrams(lyrics_train00))
    trigram10s_frequencies = calc_ngram_frequencies(generate_trigrams(lyrics_train10))

    commonTrigrams60s = nlargest(250, trigram60s_frequencies, key=trigram60s_frequencies.get)
    commonTrigrams70s = nlargest(250, trigram70s_frequencies, key=trigram70s_frequencies.get)
    commonTrigrams80s = nlargest(250, trigram80s_frequencies, key=trigram80s_frequencies.get)
    commonTrigrams90s = nlargest(250, trigram90s_frequencies, key=trigram90s_frequencies.get)
    commonTrigrams00s = nlargest(250, trigram00s_frequencies, key=trigram00s_frequencies.get)
    commonTrigrams10s = nlargest(250, trigram10s_frequencies, key=trigram10s_frequencies.get)

    commonTrigrams = commonTrigrams60s + commonTrigrams70s + commonTrigrams80s + commonTrigrams90s + commonTrigrams00s + commonTrigrams10s
    commonTrigramsWithoutDuplicates = list(set(commonTrigrams))

    return commonTrigramsWithoutDuplicates

# This function gets as an input a song and stores the values of the different features of this song in a vector.
def extract_features_boolean(song):

    features = []

    tokens = re.compile('\w+').findall(song)

    bigrams = generate_bigrams_one_song(tokens)
    trigrams = generate_trigrams_one_song(tokens)

    # Feature 1: Number of tokens in lyrics
    #numberOfFeatures += 1
    numberOfWords = len(tokens)
    features.append(numberOfWords)


    # Feature 2 - 5: Number of repetition occurences (lexical richness)
    for i in range(1, 6):
        features.append(calcNumberOfRepetitions(tokens, song, i))


    # Feature 6: Average word length
    features.append(calcAverageWordLength(tokens, numberOfWords))


    # Feature Group: Part of speech tags
    partOfSpeechTags = nltk.pos_tag(tokens)
    for tag in possibleTags:
        features.append(calcTagOccurences(partOfSpeechTags, tag))

    # Feature Group: n-gram frequencies
    for word in commonWords:
        termfrequency = sum(1 for _ in re.finditer(r'\b%s\b' % re.escape(word), song))
        features.append(termfrequency)

    for bigram in commonBigrams:
        bigramFrequency = calc_ngram_occurence(bigrams, bigram)
        features.append(bigramFrequency)

    for trigram in commonTrigrams:
        trigramFrequceny = calc_ngram_occurence(trigrams, trigram)
        features.append(trigramFrequceny)

    # Feature group: Sentiment and polarity
    blob = TextBlob(song)
    features.append(blob.sentiment[0])
    features.append(blob.sentiment[1])

    # Feature group: Stopword frequencies

    for stopword in stop_words_all:
        stopwordFreq = sum(1 for _ in re.finditer(r'\b%s\b' % re.escape(stopword), song))
        features.append(stopwordFreq)


    return features




commonWords = generateCommonWords()
commonBigrams = generateCommonBigrams()
commonTrigrams = generateCommonTrigrams()


train_data = list(map(extract_features_boolean, lyrics_train))
test_data = list(map(extract_features_boolean, lyrics_test))


