__author__ = 'Daphne Lenders'
import ExtractData
import sklearn
from sklearn import svm, cross_validation
from sklearn.metrics import confusion_matrix
from imblearn.over_sampling import SMOTE
import xlsxwriter

X_train_data = ExtractData.train_data
y_train_data = ExtractData.lyricsLabels_train

X_test_data = ExtractData.test_data
y_test_data = ExtractData.lyricsLabels_test

X_train_data, y_train_data = SMOTE().fit_sample(X_train_data, y_train_data)

lyricsTest = ExtractData.lyrics_test
lyricLabelsTest = ExtractData.lyricsLabels_test

# This function was used before the classifier was tested on the test-set. 10-fold cross validation is used to split
# the training set into a training- and validation set
def create_folds(X_train, y_train):
    data_splitted_10_fold = cross_validation.KFold(len(y_train), n_folds=10, shuffle=True, random_state=1)
    folds = []
    for train_index, validation_index in data_splitted_10_fold:
        train_data, validation_data = X_train[train_index], X_train[validation_index]
        train_labels = y_train[train_index]
        validation_labels = y_train[validation_index]
        folds.append((train_data, train_labels, validation_data, validation_labels))
    return folds


# This function was used before the classifier was tested on the test-set. The classifier is trained and tested on
# ten different training- and validation set. The performance on each validation set is visualized through a confusion
# matrix.
def classify(folds):
    for (train_data, train_labels, validation_data, validation_labels) in folds:
        clf = svm.SVC(kernel='linear')
        clf.fit(train_data, train_labels)
        validation_prediction = clf.predict(validation_data)
        print(confusion_matrix(validation_labels, validation_prediction,
                               labels=['1960', '1970', '1980', '1990', '2000', '2010']))
        evaluate(validation_labels, validation_prediction)

# Given the predicted class labels and the true class labels, this function prints out the recall, precision and f1-score
# of a classifier.
def evaluate(y_true, y_pred):
    recall = sklearn.metrics.recall_score(y_true, y_pred, average='macro')
    print("Recall: %f" % recall)

    precision = sklearn.metrics.precision_score(y_true, y_pred, average='macro')
    print("Precision: %f" % precision)

    f1_score = 2 * (precision * recall)/(precision + recall)
    print("F1-score: %f" % f1_score)

    return recall, precision, f1_score

# The lyrics of a song, the corresponding decade plus the predicted decade are visualized in an excel-sheet called 'Predictions'.
# Two different sheets are made, one containing the data of the rightly predicted songs, and the other one containing data of
# the wrongly predicted songs.
def writeInExcelSheet(rightPredictions, wrongPredictions):
    workbook = xlsxwriter.Workbook('Predictions.xlsx')
    rights = workbook.add_worksheet('Right Predictions')
    wrongs = workbook.add_worksheet('Wrong Predictions')

    rights.write(0, 0, 'Lyrics')
    rights.write(0, 1, 'Label')
    rights.write(0, 2, 'Prediction')
    row = 1
    col = 0

    for lyrics, true_label, prediction in rightPredictions:
        rights.write(row, col, lyrics)
        rights.write(row, col+1, true_label)
        rights.write(row, col+2, prediction)
        col = 0
        row+=1

    wrongs.write(0, 0, 'Lyrics')
    wrongs.write(0, 1, 'Label')
    wrongs.write(0, 2, 'Prediction')
    row = 1
    col = 0
    for lyrics, true_label, prediction in wrongPredictions:
        wrongs.write(row, col, lyrics)
        wrongs.write(row, col + 1, true_label)
        wrongs.write(row, col + 2, prediction)
        col = 0
        row +=1

    workbook.close()

# The lyrics that have been assigned the correct production-decade and the lyrics that have been assigned wrong
# production decades are stored into seperate array. Afterwards the function 'writeInExcelSheet' is called so the
# data can be visualized in an Excel-file.
def makeOverview():
   iterator = 0
   rightPredictions = []
   wrongPredictions = []
   for prediction in test_prediction:
       if prediction == lyricLabelsTest[iterator]:
           rightPredictions.append((lyricsTest[iterator], lyricLabelsTest[iterator], prediction))
       else:
           wrongPredictions.append((lyricsTest[iterator], lyricLabelsTest[iterator], prediction))
       iterator+=1

   writeInExcelSheet(rightPredictions, wrongPredictions)

# Through the ZeroRule Method all test-instances are predicted to be part of the majority-class of the training
# data-set. In this case the majority class of the training data set is 1980
def ZeroRuleMethod():
    predictions = []
    for i in range (0, y_test_data.size):
        predictions.append('1980')
    print(confusion_matrix(y_test_data, predictions,
                       labels=['1960', '1970', '1980', '1990', '2000', '2010']))
    evaluate(y_test_data, predictions)


# The classifier is trained on the test set!
clf = svm.SVC(kernel='linear')
clf.fit(X_train_data, y_train_data)
test_prediction = clf.predict(X_test_data)
print(confusion_matrix(y_test_data, test_prediction,
                       labels=['1960', '1970', '1980', '1990', '2000', '2010']))
evaluate(y_test_data, test_prediction)
#makeOverview()
